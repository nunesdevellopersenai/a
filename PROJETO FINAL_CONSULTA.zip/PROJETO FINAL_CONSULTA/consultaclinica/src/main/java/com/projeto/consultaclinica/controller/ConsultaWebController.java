package com.projeto.consultaclinica.controller;

import com.projeto.consultaclinica.model.Consulta;
import com.projeto.consultaclinica.repository.ConsultaRepository;
import com.projeto.consultaclinica.repository.PacienteRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/consultas")
public class ConsultaWebController {

    private final ConsultaRepository consultaRepository;
    private final PacienteRepository pacienteRepository;

    public ConsultaWebController(ConsultaRepository consultaRepository,
                                 PacienteRepository pacienteRepository) {
        this.consultaRepository = consultaRepository;
        this.pacienteRepository = pacienteRepository;
    }

    // ================================
    // LISTAR CONSULTAS (URL: /consultas)
    // ================================
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("consultas", consultaRepository.findAll());
        return "lista-consultas";
    }

    // ================================
    // ATALHO PARA LISTA (URL: /consultas/lista)
    // ================================
    @GetMapping("/lista")
    public String listarAlias() {
        return "redirect:/consultas";
    }

    // ================================
    // FORMULÁRIO NOVA CONSULTA (URL: /consultas/nova)
    // ================================
    @GetMapping("/nova")
    public String exibirFormulario(Model model) {
        model.addAttribute("consulta", new Consulta());
        model.addAttribute("pacientes", pacienteRepository.findAll());
        return "agendar-consulta";
    }

    // ================================
    // SALVAR CONSULTA
    // ================================
    @PostMapping("/salvar")
    public String salvar(@ModelAttribute("consulta") Consulta consulta) {
        consultaRepository.save(consulta);
        return "redirect:/consultas";
    }

    // ================================
    // EXCLUIR CONSULTA
    // ================================
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        consultaRepository.deleteById(id);
        return "redirect:/consultas";
    }
}